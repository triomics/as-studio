<?php 
/* Template name: Контакти */

get_header (); ?>


<?php get_footer(); ?>