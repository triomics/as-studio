<?php 
/* Template name: Вакансії */

get_header (); ?>


<?php get_footer(); ?>