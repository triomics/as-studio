<?php 
/* Template name: Про мене */

get_header (); ?>


<?php get_footer(); ?>