<?php
/**
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package WordPress
 * @subpackage AS
 * @since AS 1.0
 */

function as_setup() {

	add_theme_support( 'title-tag' );

	add_theme_support( 'custom-logo', array(
		'height'      => 240,
		'width'       => 240,
		'flex-height' => true,
	) );

	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 9999 );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( 'Left Menu', 'as' ),
		'mobile'  => __( 'Mobile Menu', 'as' ),
		'footer'  => __( 'Mobile Menu', 'as' ),
	) );

	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	add_editor_style( array( 'css/editor-style.css', twentysixteen_fonts_url() ) );

	add_theme_support( 'customize-selective-refresh-widgets' );
}

endif; // as_setup

add_action( 'after_setup_theme', 'as_setup' );


if(!function_exists("as_scripts")){
    function as_scripts() {

    	wp_enqueue_script('jquery');
    	
    	$js_dir   = get_template_directory_uri() . "assets/js/";

    	$js_files = array("app", "bootstrap", "bootstrap.min");

    	
    	foreach($js_files as $file){
    		$label = str_replace(".", "", $file);
    		
    		wp_register_script($label, $js_dir . $file . '.js', array('jquery'), '1.0.0', true);
    		wp_enqueue_script($label);
    	}
    }
}


if(!function_exists("as_styles")){
    function as_styles() {
        if ($GLOBALS['pagenow'] != 'wp-login.php' && !is_admin()) {

    		$css_dir   = get_template_directory_uri() . "assets/css/";		
    		$css_files = array("app");
    		

    		foreach($css_files as $file){		
    			$label = str_replace(".", "", $file);
    		
    			wp_register_style($label, $css_dir . $file . '.css', array(), '1.1', 'all');
    			wp_enqueue_style($label);
    		}

        }
    }
}